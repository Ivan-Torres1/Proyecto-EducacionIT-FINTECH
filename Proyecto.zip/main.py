from fintech.modelos.Usuario import Usuario

# from fintech.modelos import *


usuario = Usuario("Ivan","Torres",47103883,"ivantorres@gmail.com","1234")
usuario.crearCuenta()
usuario.mostrarCuentas()
usuario.crearCuenta()
usuario.crearCuenta()
usuario.mostrarCuentas()